Python client library for the InComfort LAN2RF gateway.

Also contains a munin plugin.
